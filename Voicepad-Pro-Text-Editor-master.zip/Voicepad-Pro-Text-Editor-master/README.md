# Voicepad-Pro-Text-Editor
This is a much simpler version of our beloved Notepad with added Speech-to-text and Text-to-speech feature.

# Features
1. Speech input
2. Story telling mode (Text-to-Speech feature)
3. Easy to change Font type and Font size
4. Added Bold, Italic and Underline button
5. Easy text alignment with Right, Left and Center Align Buttons.
6. Attractive Interface

# Requirements
1. Tkinter (pre installed with Python)
2. OS (pre installed with python)
3. pip install pyttsx3
4. pip install SpeechRecognition
5. pip install PyAudio

